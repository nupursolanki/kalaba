<?php
	
	get_header();

?>
test

<?php get_footer() ?>